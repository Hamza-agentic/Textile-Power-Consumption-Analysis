"""
Textile Factory Power Consumption Predictor
Run from the project root:  streamlit run app.py
"""
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st

# ----------------------------------------------------------------------------
# Settings
# ----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "best_model.pkl"
FEATURES_PATH = BASE_DIR / "models" / "feature_columns.pkl"
DATA_PATH = BASE_DIR / "data" / "textile_power_consumption_2500_realistic_shift.csv"

TYPICAL_ERROR = 19   # model MAE on the test set (power units), from notebook 05

DEFAULTS = {   # (min, max, default), used if the CSV is not found
    "temperature": (15.0, 40.0, 27.0),
    "humidity": (55.0, 90.0, 72.0),
    "production_units": (50.0, 500.0, 260.0),
    "machine_hours": (5.0, 24.0, 14.0),
    "machine_count": (8, 25, 16),
    "machine_load_percent": (40.0, 97.0, 67.0),
}

st.set_page_config(page_title="Power Consumption Predictor", page_icon="⚡", layout="centered")


# ----------------------------------------------------------------------------
# Loading
# ----------------------------------------------------------------------------
@st.cache_resource
def load_model():
    model = joblib.load(MODEL_PATH)
    features = joblib.load(FEATURES_PATH) if FEATURES_PATH.exists() else None
    return model, features


@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH) if DATA_PATH.exists() else None


try:
    model, saved_features = load_model()
except Exception as e:
    st.error(f"Could not load the model from `{MODEL_PATH}`.\n\n{e}")
    st.stop()

data = load_data()
FEATURES = saved_features or ["temperature", "humidity", "production_units", "machine_hours",
                              "machine_count", "machine_load_percent", "shift"]


def limits(col):
    """(min, max, default) taken from the training data."""
    if data is not None:
        lo, hi, mid = data[col].min(), data[col].max(), data[col].median()
        if col == "machine_count":
            return int(lo), int(hi), int(round(mid))
        return float(np.floor(lo)), float(np.ceil(hi)), float(round(mid, 1))
    return DEFAULTS[col]


# ----------------------------------------------------------------------------
# Page
# ----------------------------------------------------------------------------
st.title("⚡ Factory Power Consumption Predictor")
st.write("Enter the factory conditions below and click **Predict**.")

with st.form("inputs"):
    st.subheader("Factory conditions")

    c1, c2, c3 = st.columns(3)
    lo, hi, mid = limits("temperature")
    temperature = c1.number_input("Temperature (°C)", lo, hi, mid, 0.5, help=f"Range in data: {lo:g} to {hi:g}")
    lo, hi, mid = limits("humidity")
    humidity = c2.number_input("Humidity (%)", lo, hi, mid, 0.5, help=f"Range in data: {lo:g} to {hi:g}")
    lo, hi, mid = limits("production_units")
    production = c3.number_input("Production units", lo, hi, mid, 5.0, help=f"Range in data: {lo:g} to {hi:g}")

    c4, c5, c6 = st.columns(3)
    lo, hi, mid = limits("machine_hours")
    hours = c4.number_input("Machine hours", lo, hi, mid, 0.5, help=f"Range in data: {lo:g} to {hi:g}")
    lo, hi, mid = limits("machine_count")
    count = c5.number_input("Machine count", lo, hi, mid, 1, help=f"Range in data: {lo} to {hi}")
    lo, hi, mid = limits("machine_load_percent")
    load = c6.number_input("Machine load (%)", lo, hi, mid, 0.5, help=f"Range in data: {lo:g} to {hi:g}")

    shift_label = st.radio("Shift", ["Day", "Night"], horizontal=True)

    submitted = st.form_submit_button("Predict Power Consumption", type="primary", use_container_width=True)

if submitted:
    row = pd.DataFrame([{
        "temperature": temperature,
        "humidity": humidity,
        "production_units": production,
        "machine_hours": hours,
        "machine_count": count,
        "machine_load_percent": load,
        "shift": 0 if shift_label == "Day" else 1,
    }])[FEATURES]

    power = float(max(model.predict(row)[0], 0))

    st.divider()
    st.subheader("Predicted power consumption")
    st.metric("Predicted power", f"{power:,.1f}")

    m1, m2 = st.columns(2)
    m1.metric("Typical range", f"{max(power - TYPICAL_ERROR, 0):,.0f} to {power + TYPICAL_ERROR:,.0f}",
              help=f"The model's average error is about {TYPICAL_ERROR} units.")
    m2.metric("Power per unit produced", f"{power / production:.2f}")

    ppu = power / production

    if data is not None:
        avg = data["power_consumption"].mean()
        diff = (power - avg) / avg * 100
        st.caption(f"Plant average power is {avg:,.0f}, so this prediction is "
                   f"{abs(diff):.0f}% {'higher' if diff >= 0 else 'lower'} than average.")

    # ---- Explanation of the results ------------------------------------------
    st.markdown("#### How to read these results")
    st.markdown(
        f"- **Predicted power ({power:,.1f}):** the power the factory is expected to use under the conditions you entered.\n"
        f"- **Typical range ({max(power - TYPICAL_ERROR, 0):,.0f} to {power + TYPICAL_ERROR:,.0f}):** "
        f"the model is usually off by about {TYPICAL_ERROR} units, so the real value is likely inside this range.\n"
        f"- **Power per unit produced ({ppu:.2f}):** how much power is used to make one unit of product "
        f"(predicted power ÷ production units = {power:,.1f} ÷ {production:,.0f}). **Lower is better**, because less power is used for each unit made."
    )

    if data is not None:
        hist_ppu = data["power_consumption"] / data["production_units"]
        better_than = float((hist_ppu > ppu).mean() * 100)
        if better_than >= 60:
            verdict, advice = "🟢 Efficient", "The factory uses less power per unit than in most past records."
        elif better_than >= 30:
            verdict, advice = "🟡 Average", "Efficiency is about normal for this factory."
        else:
            verdict, advice = "🔴 High usage", ("The factory uses more power per unit than in most past records. "
                                               "This usually happens when production or machine load is low, "
                                               "because machines still use power while making fewer products.")
        st.info(f"**Efficiency: {verdict}.** At {ppu:.2f}, this is better than {better_than:.0f}% of past records "
                f"(plant average is {hist_ppu.mean():.2f}). {advice}")
